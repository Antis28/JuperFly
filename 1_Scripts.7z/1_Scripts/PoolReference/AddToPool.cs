﻿using UnityEngine;
using System.Collections;
using System;

public class AddToPool : MonoBehaviour {

    //PoolReference pool;   
	// Use this for initialization
	void Awake () {

        //pool = GameObject.Find("PoolReference").GetComponent<PoolReference>();

        try
        {            
            PoolReference.TableScene.Add(name.ToString(), gameObject);            
        }
        catch(NullReferenceException )
        {
            print("Нет ссылки на объект ");
        }
        /* 
        catch(ArgumentException )
        {
            print("AddToPool - ключ уже существует, пытаюсь исправить ошибку ");
            try
            {
                PoolReference.TableScene[name.ToString()] = gameObject;
            }
            catch (ArgumentException )
            {
                print("AddToPool error!!!!!!!!!!!!!!");
            }
        }
        */
    }
}
