﻿using UnityEngine;
using System.Collections;
using System;

// Основные характеристики
public interface IVital
{
    int Intellect { get; }
    int Strength  { get; }
    int Speed     { get; }      
}
// Опыт
public interface IExperience
{
    int Experience { get; set; }
    int Level { get;}

    void LevelUp();
}

public class Vital : IVital, IExperience
{
    int _experience;
    int _remainToUp = 100; // осталось до следующего уровня?
    int _level;

    public int Intellect
    { get; private set; }

    public int Strength
    { get; private set; }    

    public int Speed
    { get; private set; }

    public int Experience
    {
        get
        { return _experience;}

        set
        {
            if (_experience > _remainToUp)
                LevelUp();
            else
                _experience = value;
        }
    }

    public int Level
    { get; private set; }

    public void LevelUp()
    {
        throw new NotImplementedException();
    }
}
