﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Xml;
using System.IO;



public class TaskManeger : MonoBehaviour {

	[HideInInspector] public Text coinText;
	[HideInInspector] public Text BonusFlyText;
	[HideInInspector] public Image PriceImageTask;
	[HideInInspector] public InputField AnswerInputField;
	[HideInInspector] public Text  taskHeaderText;
	[HideInInspector] public Text  taskText;
	[HideInInspector] public Text  BonusTextTask;
	[HideInInspector] public Image taskImage;
	[HideInInspector] public Image BonusImageTask;
	[HideInInspector] public Button newButton;
	[HideInInspector] public Button nextButton;
	[HideInInspector] public Button previoustButton;
	[HideInInspector] public Button exitButton;
	[HideInInspector] public Button BackButton;
	[HideInInspector] public Canvas TaskCanvas;
	[HideInInspector] public Canvas GameCanvas;

	[HideInInspector] public Image FlyImageTask;
	[HideInInspector] public Text FlyTextTask;
	[HideInInspector] public LoadStats LS;

	[HideInInspector] public Vector3 exitPosition;
	public string 	answer;
	public int numTask;
	public bool isAnswer;
	private int costTask;
	private int loadNumTask;


	[HideInInspector] public Image panelImage;
	[HideInInspector] public Sprite panelImageOriginal;
	[HideInInspector] public Image panelImageAnswer;
	[HideInInspector] public Image panelImageNoAnswer;
	[HideInInspector] public string putTaskBase ="Data/Save/TaskBase.xml";

	 public PoolR poolr;

	void Start()
	{
		costTask = 10;
		poolr = GameObject.Find("PoolReference").GetComponent<PoolR>();
		TaskCanvas.gameObject.SetActive (false);
		VisibleTask ();
		poolr.TaskNumber.enabled = false;

		if (!File.Exists (putTaskBase)) {
			TaskGenerator tg = new TaskGenerator ();
			tg.GenerationXML ();
		}
		ReadXML ();

		Debug.Log(poolr.loadStats.numTask);
		loadNumTask = poolr.loadStats.numTask;
		if(numTask < loadNumTask)
			numTask = loadNumTask;
		
		FlyTextTask.text = poolr.bonusControler.amountOfBonuses.ToString();
		BonusTextTask.text = coinText.text;
		
		if (numTask < 1)
			numTask = 1;
	}
	void Awake(){

	}

	void OnEnable()
	{
//		Debug.Log(poolr.loadStats.numTask);
//		loadNumTask = poolr.loadStats.numTask;
//		if(numTask < loadNumTask)
//			numTask = loadNumTask;

//		FlyTextTask.text = poolr.bonusControler.amountOfBonuses.ToString();
//		FlyTextTask.text = "10\xC2B9";
//		BonusTextTask.text = coinText.text;

		if (numTask < 1)
			numTask = 1;

	}

	 


	public void Answer()
	{
		if (!isAnswer) {  
			//panelImageOriginal = panelImage.sprite;
			if (answer == AnswerInputField.text) {			
				panelImage.sprite = panelImageAnswer.sprite;

				poolr.bonusControler.amountOfBonuses += 2;
				FlyTextTask.text = poolr.bonusControler.amountOfBonuses.ToString();



				Debug.Log ("UUUUUUUUUUUUraaaaaaaaaaaaaaaaaa");
				isAnswer = !isAnswer;
				++numTask;
			}
			else
				panelImage.sprite = panelImageNoAnswer.sprite;

		}

	}
	public void TakeTask()
	{
		if (System.Int32.Parse (coinText.text) > costTask) {
					

			poolr.newButton.enabled = ReadXML ();
			if(ReadXML ())
			{
				coinText.text = (System.Int32.Parse (coinText.text) - costTask).ToString();
				VisibleTaskMainMenu ();
				VisibleTask ();
				poolr.TaskNumber.enabled = true;
				poolr.TaskNumber.text = numTask.ToString();

			}

		}
	}
	public void BackMenu()
	{
		VisibleTaskMainMenu ();
		VisibleTask ();
		panelImage.sprite = panelImageOriginal;
		poolr.TaskNumber.enabled = false;
	}
	public void TakeExit()
	{
		if( numTask > 1)
		{
			SaveStats ss = new SaveStats();
			ss.SaveStatistik(numTask.ToString(), "NumberTask");
		}

			Shop shop = poolr.shop;
			shop.simplePC.enabled = !shop.simplePC.enabled;

			GameCanvas.gameObject.SetActive (!GameCanvas.gameObject.activeSelf);
			TaskCanvas.gameObject.SetActive (!TaskCanvas.gameObject.activeSelf);


			Debug.Log ("TakeExit()");
		
	}

	bool ReadXML()
	{
		//Многоугольник и его периметр. Равные фигуры.
		//Сумма всех сторон многоугольника называется периметром многоугольника.
		//Две фигуры называются равными, если они совмещаются наложением.

		if(File.Exists("Data/Save/TaskBase.xml"))
		{
			XmlDocument xml = new XmlDocument();
			xml.Load("Data/Save/TaskBase.xml");
			foreach (XmlElement element in xml.GetElementsByTagName("Task_" + numTask))
			{
				foreach (XmlElement e in element)
				{
					if(e.Name == "Header")
						taskHeaderText.text = e.InnerText;
					if(e.Name == "Question")
						taskText.text = e.InnerText;
					if(e.Name == "Answer")
						answer = e.InnerText;
					if(e.Name == "IsAnswer")
					{
						isAnswer = System.Boolean.Parse(e.InnerText); //.ToString()
					}
				}
				//Debug.Log("Есть задание №" + numTask);
				return true;
			}				
		}
		//Debug.Log("Нет задания №" + numTask);
		return false;
	}


	void VisibleTask()
	{		
		taskHeaderText.enabled = !taskHeaderText.enabled;
		taskText.enabled = !taskText.enabled;
		taskImage.enabled = !taskImage.enabled;

		nextButton.gameObject.SetActive (!nextButton.gameObject.activeSelf);

		AnswerInputField.gameObject.SetActive (!AnswerInputField.gameObject.activeSelf);
		BackButton.gameObject.SetActive (!BackButton.gameObject.activeSelf);
		//BonusTextTask.gameObject.SetActive (!BonusTextTask.gameObject.activeSelf);
		//BonusImageTask.gameObject.SetActive (!BonusImageTask.gameObject.activeSelf);
		//previoustButton.gameObject.SetActive (!previoustButton.gameObject.activeSelf);
		//FlyTextTask.gameObject.SetActive (!FlyTextTask.gameObject.activeSelf);
		//FlyImageTask.gameObject.SetActive (!FlyImageTask.gameObject.activeSelf);


		BonusTextTask.text = coinText.text;
//		Debug.Log ("VisibleTask()");

	}
	void VisibleTaskMainMenu()
	{
		newButton.gameObject.SetActive (!newButton.gameObject.activeSelf);
		exitButton.gameObject.SetActive (!exitButton.gameObject.activeSelf);
		BonusTextTask.text = coinText.text;
		PriceImageTask.gameObject.SetActive (!PriceImageTask.gameObject.activeSelf);
		Debug.Log ("VisibleTaskMainMenu()");

		
	}
}


